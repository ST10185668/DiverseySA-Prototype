// Add event listeners to edit and remove buttons
document.querySelectorAll('.editProductBtn').forEach(button => {
    button.addEventListener('click', () => {
        const productsId = button.dataset.productsId;
        openEditModal(productsId);
    });
});

document.querySelectorAll('.removeProductBtn').forEach(button => {
    button.addEventListener('click', () => {
        const productsId = button.dataset.productsId;
        removeProducts(productsId);
    });
});

// Function to open edit modal
function openEditModal(productId) {
    const editModal = document.getElementById('editModal');
    const editForm = document.getElementById('editForm');

    // Assuming you have a function getProductDetails(productId) to fetch product details
    const productDetails = getProductDetails(productId);

    // Populate the form fields with product details
    editForm.elements['editProductId'].value = productId;
    editForm.elements['editProductName'].value = productDetails.name;
    editForm.elements['editProductDescription'].value = productDetails.description;
    editForm.elements['editProductCost'].value = productDetails.cost;

    // Display the modal
    editModal.style.display = 'block';
}


const products = [
    { id: 1, name: "Soap", description: "Argosy is a top quality, individually wrapped toilet soap which carries the SABS 237 Toilet Soap mark. Argosy is ideal for use in hotels, boarding houses, restaurants and all major institutions and can be used anywhere if a top quality toilet soap is required."},
    { id: 2, name: "Liquid", description: "Sumabrite™ Concentrated Dishwashing Liquid Gel 500ml is a concentrated dishwash liquid gel that is effective in removing all grease and food stains from crockery, utensils and cutlery."},
    { id: 3, name: "Wipes", description: "Diversey Oxivir Excel combined Cleaner & Disinfectant, powered by AHP Technology, provides you with the best alternative to your traditional disinfectants by delivering full virucidal efficacy in just 30 seconds in dirty conditions, while being very gentle to surfaces and with the lowest risk to your staff and customer."}
];

// Function to get product details by ID
function getProductDetails(productId) {
    return products.find(product => products.id === parseInt(productId));
}



// Function to remove product
function removeProducts(productsId) {
    const confirmation = confirm("Are you sure you want to remove this product?");
    if (confirmation) {
        // Remove the product from the UI
        const productRow = document.querySelector(`tr[data-product-id="${productsId}"]`);
        if (productRow) {
            productRow.remove();
            alert("Product removed successfully!");
        } else {
            alert("Product not found!");
        }
    }
}


document.addEventListener("DOMContentLoaded", function() {
    // Select the "See all" button for new products
    var seeAllProductsButton = document.getElementById("seeAllProducts");

    // Add click event listener to the button
    seeAllProductsButton.addEventListener("click", function() {
        // Redirect to the products page (replace the URL with your actual products page URL)
        window.location.href = "products.html";
    });
});

document.addEventListener("DOMContentLoaded", function() {
    // Select the "See all" button for new products
    var seeAllProductsButton = document.getElementById("seeAllCustomers");

    // Add click event listener to the button
    seeAllProductsButton.addEventListener("click", function() {
        // Redirect to the products page (replace the URL with your actual products page URL)
        window.location.href = "customer.html";
    });
});

document.addEventListener("DOMContentLoaded", function() {
    // Add button functionality
    document.getElementById("addButton").addEventListener("click", function() {
        // Implement functionality to add a product
        console.log("Add button clicked");
    });

    // Edit button functionality
    var editButtons = document.getElementsByClassName("editButton");
    for (var i = 0; i < editButtons.length; i++) {
        editButtons[i].addEventListener("click", function() {
            //  functionality to edit the corresponding product
            console.log("Edit button clicked");
        });
    }

    document.addEventListener("DOMContentLoaded", function() {
        var addForm = document.getElementById("addForm");
    
        addForm.addEventListener("submit", function(event) {
            // Prevent form submission
    
            // Get form input values
            var productId = document.getElementById("productId").value;
            var productName = document.getElementById("productName").value;
            var productDescription = document.getElementById("productDescription").value;
            var productCost = document.getElementById("productCost").value;
    
            // Append new product to table
            var tableBody = document.querySelector(".product-box tbody");
            var newRow = document.createElement("tr");
            newRow.innerHTML = `
                <td>${productId}</td>
                <td><strong>${productName}</strong></td>
                <td>${productDescription}</td>
                <td>${productCost}</td>
                <td>
                    <div class="ed-it">
                        <button onclick="openEditModal(${productId})">Edit<span class="edit"></span></button>
                    </div>
                    <div class="rem-ove">
                        <button onclick="removeProduct(${productId})">Remove<span class="Remove"></span></button>
                    </div>
                </td>
            `;
            tableBody.appendChild(newRow);
    
            // Close the Add Modal
            closeAddModal();
    
            // Optionally, you can clear the form fields here
            addForm.reset();
        });
    });
        

    // Remove button functionality
    var removeButtons = document.getElementsByClassName("removeButton");
    for (var i = 0; i < removeButtons.length; i++) {
        removeButtons[i].addEventListener("click", function() {
            // functionality to remove the corresponding product
            console.log("Remove button clicked");
        });
    }
});

 // Get the modal elements
 var addModal = document.getElementById("addModal");
 var editModal = document.getElementById("editModal");

 // Function to open Add Modal
 function openAddModal() {
     addModal.style.display = "block";
 }

 // Function to close Add Modal
 function closeAddModal() {
     addModal.style.display = "none";
 }

 // Function to open Edit Modal and populate with product details
 function openEditModal(productId) {
     editModal.style.display = "block";
     document.getElementById("editProductId").value = productId;
     document.getElementById("editProductName").value = ""; // Populate with product name
     document.getElementById("editProductDescription").value = ""; // Populate with product description
     document.getElementById("editProductCost").value = ""; // Populate with product cost
 }

 // Function to close Edit Modal
 function closeEditModal() {
     editModal.style.display = "none";
 }

 // Function to remove a product
 function removeProduct(productId) {
    // Find the row corresponding to the productId
    var rowToRemove = document.querySelector('tr[data-product-id="' + productId + '"]');
    if (rowToRemove) {
        // Remove the row
        rowToRemove.remove();
    }
}

 // Close the modals when the user clicks outside the modal content
 window.onclick = function(event) {
     if (event.target == addModal) {
         addModal.style.display = "none";
     }
     if (event.target == editModal) {
         editModal.style.display = "none";
     }
 }
